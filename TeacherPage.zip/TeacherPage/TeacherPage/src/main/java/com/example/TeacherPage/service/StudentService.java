package com.example.TeacherPage.service;

import com.example.TeacherPage.model.student;
import com.example.TeacherPage.repository.StudentRepository;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

@Service
public class StudentService {
    private final StudentRepository repo;
    public StudentService(StudentRepository repo) { this.repo = repo; }

    public List<student> findAll() { return repo.findAll(); }
    public student save(student s) { return repo.save(s); }
    public Optional<student> findById(Long id) { return repo.findById(id); }
    public void deleteById(Long id) { repo.deleteById(id); }
}
