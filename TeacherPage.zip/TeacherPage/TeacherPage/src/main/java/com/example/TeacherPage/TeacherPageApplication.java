package com.example.TeacherPage;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TeacherPageApplication {

	public static void main(String[] args) {
		SpringApplication.run(TeacherPageApplication.class, args);
	}

}


/*

✅ **Home Page:**
👉 http://localhost:8080/teachers/

✅ **Add New Teacher:**
👉 http://localhost:8080/teachers/add

✅ **List All Teachers:**
👉 http://localhost:8080/teachers/list

*/