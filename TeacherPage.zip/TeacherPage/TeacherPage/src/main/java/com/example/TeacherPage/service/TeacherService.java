package com.example.TeacherPage.service;

import com.example.TeacherPage.model.teacher;
import com.example.TeacherPage.repository.TeacherRepository;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

@Service
public class TeacherService {
    private final TeacherRepository repo;
    public TeacherService(TeacherRepository repo) { this.repo = repo; }

    public List<teacher> findAll() { return repo.findAll(); }
    public teacher save(teacher t) { return repo.save(t); }
    public Optional<teacher> findById(Long id) { return repo.findById(id); }
    public void deleteById(Long id) { repo.deleteById(id); }
}
