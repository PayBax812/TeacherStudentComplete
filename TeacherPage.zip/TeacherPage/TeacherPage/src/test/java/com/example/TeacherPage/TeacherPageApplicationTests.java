package com.example.TeacherPage;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TeacherPageApplicationTests {

	@Test
	void contextLoads() {
	}

}
