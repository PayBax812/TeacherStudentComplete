package com.example.TeacherPage.repository;

import com.example.TeacherPage.model.student;
import org.springframework.data.jpa.repository.JpaRepository;

	
	public interface StudentRepository extends JpaRepository<student, Long>{
}
