package com.example.TeacherPage.controller;

import com.example.TeacherPage.model.student;
import com.example.TeacherPage.service.StudentService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/students")
public class StudentController {
    private final StudentService studentService;
    public StudentController(StudentService studentService) { this.studentService = studentService; }

    @GetMapping("/list")
    public String listStudents(Model model) {
        model.addAttribute("students", studentService.findAll());
        return "students/list-students";
    }

    @GetMapping("/add")
    public String addStudentForm(Model model) {
        model.addAttribute("student", new student());
        return "students/add-student";
    }

    @PostMapping("/save")
    public String saveStudent(@ModelAttribute student student) {
        studentService.save(student);
        return "redirect:/students/list";
    }

    @GetMapping("/edit/{id}")
    public String editStudent(@PathVariable Long id, Model model) {
        studentService.findById(id).ifPresent(s -> model.addAttribute("student", s));
        return "students/add-student";
    }

    @GetMapping("/delete/{id}")
    public String deleteStudent(@PathVariable Long id) {
        studentService.deleteById(id);
        return "redirect:/students/list";
    }
}
