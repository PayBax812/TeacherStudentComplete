package com.example.TeacherPage.controller;

import com.example.TeacherPage.model.teacher;
import com.example.TeacherPage.service.TeacherService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/teachers")
public class TeacherController {
    private final TeacherService teacherService;
    public TeacherController(TeacherService teacherService) { this.teacherService = teacherService; }

    @GetMapping("/list")
    public String listTeachers(Model model) {
        model.addAttribute("teachers", teacherService.findAll());
        return "teachers/list-teachers";
    }

    @GetMapping("/add")
    public String addTeacherForm(Model model) {
        model.addAttribute("teacher", new teacher());
        return "teachers/add-teacher";
    }

    @PostMapping("/save")
    public String saveTeacher(@ModelAttribute teacher teacher) {
        teacherService.save(teacher);
        return "redirect:/teachers/list";
    }

    @GetMapping("/edit/{id}")
    public String editTeacher(@PathVariable Long id, Model model) {
        teacherService.findById(id).ifPresent(t -> model.addAttribute("teacher", t));
        return "teachers/add-teacher";
    }

    @GetMapping("/delete/{id}")
    public String deleteTeacher(@PathVariable Long id) {
        teacherService.deleteById(id);
        return "redirect:/teachers/list";
    }
}
