document.addEventListener('DOMContentLoaded', () => {
  console.log("✅ JS Loaded Successfully");

  // Tabs switching
  const tabs = document.querySelectorAll('.tab');
  tabs.forEach(tab => {
    tab.addEventListener('click', () => {
      tabs.forEach(t => t.classList.remove('active'));
      tab.classList.add('active');
    });
  });

  // Modal elements
  const addPromptBtn = document.querySelector('.add-prompt-btn');
  const modal = document.getElementById('addPromptModal');
  const closeBtn = document.querySelector('.close-btn');
  const savePromptBtn = document.getElementById('savePromptBtn');
  const promptInput = document.getElementById('promptInput');
  const promptList = document.querySelector('.prompt-list');

  // 🔹 NEW VARIABLE — to track whether user is editing or adding
  let editingPromptItem = null;

  // Open modal for adding new prompt
  addPromptBtn.addEventListener('click', () => {
    modal.style.display = 'block';
    promptInput.value = '';
    editingPromptItem = null; // reset to Add mode
  });

  // Close modal (X)
  closeBtn.addEventListener('click', () => {
    modal.style.display = 'none';
    editingPromptItem = null;
  });

  // Close modal on outside click
  window.addEventListener('click', (e) => {
    if (e.target === modal) {
      modal.style.display = 'none';
      editingPromptItem = null;
    }
  });

  // Save new or edited prompt
  savePromptBtn.addEventListener('click', () => {
    const newPrompt = promptInput.value.trim();
    if (!newPrompt) {
      alert('Please enter a prompt before saving.');
      return;
    }

    // 🔹 If editing, update existing prompt
    if (editingPromptItem) {
      const textSpan = editingPromptItem.querySelector('.prompt-text');
      textSpan.textContent = newPrompt;
      editingPromptItem = null;
      modal.style.display = 'none';
      return;
    }

    // Otherwise, add as a new prompt
    const newPromptItem = document.createElement('div');
    newPromptItem.classList.add('prompt-item');

    newPromptItem.innerHTML = `
      <span class="prompt-text">${newPrompt}</span>
      <span class="menu-dots">⋯</span>
      <div class="menu-popup">
        <div class="menu-option share">📤 Share</div>
        <div class="menu-option edit">✏️ Edit</div>
        <div class="menu-option delete">🗑️ Delete</div>
      </div>
    `;

    promptList.appendChild(newPromptItem);
    modal.style.display = 'none';
  });

  // Functionality of 3-dot menu
  document.addEventListener('click', (e) => {
    const allMenus = document.querySelectorAll('.menu-popup');
    allMenus.forEach(menu => menu.classList.remove('show'));

    // Open menu
    if (e.target.classList.contains('menu-dots')) {
      e.stopPropagation();
      const popup = e.target.nextElementSibling;
      popup.classList.add('show');
    }

    // Share action
    if (e.target.classList.contains('share')) {
      const text = e.target.closest('.prompt-item').querySelector('.prompt-text').textContent.trim();
      navigator.clipboard.writeText(text);
      alert('Prompt copied Successfully');
    }

    // 🔹 NEW EDIT MODULE — open popup with existing text
    if (e.target.classList.contains('edit')) {
      editingPromptItem = e.target.closest('.prompt-item'); // track which prompt to edit
      const currentText = editingPromptItem.querySelector('.prompt-text').textContent.trim();

      promptInput.value = currentText; // fill existing text in modal input
      modal.style.display = 'block'; // open the modal
    }

    // Delete action
    if (e.target.classList.contains('delete')) {
      const prompt = e.target.closest('.prompt-item');
      prompt.remove();
    }
  });
  
  // 🆕 NEW FEATURE: Double-click on prompt to send to AI Search bar
  // ===============================================================
  
  const searchInput = document.querySelector('.search-box input');
  
  // Listen for double click anywhere ont the prompt item
  
  document.addEventListener('dblclick', (e) => {
	const promptItem = e.target.closest('.prompt-item');
	if(promptItem){
		const text = promptItem.querySelector('.prompt-text').textContent.trim();
		searchInput.value = text;
		searchInput.focus();
	}
  });
});
